package com.aliucord.plugins.nitrospoof

enum class EmoteSize(val size: Int) {
    SIXTY_FOUR(64),
    FORTY(48),
    THIRTY_TWO(32)
}
